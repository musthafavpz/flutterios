package com.example.cepron

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
