class LoginCredentials {
  final String email;
  final String password;

  LoginCredentials(this.email, this.password);
}