class CurrentPlay {
  int? id, index;
  String? fileLink, fileSystem, fileName;
  CurrentPlay(
      {this.fileName, this.fileSystem, this.id, this.index, this.fileLink});
}
