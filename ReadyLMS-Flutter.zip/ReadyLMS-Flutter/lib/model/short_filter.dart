class ShortFilter {
  final String name;
  final String value;

  ShortFilter(this.name, this.value);
}

var shortFilterList = [];

var shortBasicFilterList = [];

var ratingFilterList = [];
