import 'package:flutter_riverpod/flutter_riverpod.dart';

final homeTabControllerProvider = StateProvider<int>((ref) {
  return 0;
});
